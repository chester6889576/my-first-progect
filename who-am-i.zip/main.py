print ("hello")
q1 = input("do you want to know who i am? (Y/N)\n")


if q1 == "N" or q1 == "n":
  print("yeah you do.\n")
elif q1 == "Y" or q1 == "y":
  print("good.\n")
else:
  print("invalid response. will disregaurd.\n")

q2 = input("are you milo flores?(Y/N)\n")

if q2 == "Y" or q2 == "y":
  print("you are milo flores.\n")
elif q2 == "N" or q2 == "n":
  print("you lie.\n")
else:
  print("invalid response. will disregaurd.\n")

q3 = input("do you have a girlfriend that loves you very much?(Y/N)\n")

if q3 == "N" or q3 == "n":
  print("nuh uh.\n")
elif q3 == "Y" or q3 == "y":
  print("you know it.\n")
else: 
  print("invalid response. will disregaurd.\n")

q4 = input("is today your birthday?(Y/Y)\n")

while q4 == "N" or q4 == "n":
  print("you lie, try again. ")
  q4 = input("is today your birthday?(Y/Y)\n")
if q4 == "Y" or q4 == "y":
  print("Happy Birthday Milo!!!! I love you so so so much. I hope you have the best day ever. Can't wait to see you. \n Love, \n Mila <3")

